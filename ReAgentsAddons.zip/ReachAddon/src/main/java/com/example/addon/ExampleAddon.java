package com.example.addon;

import autismclient.api.ApiVersion;
import autismclient.api.AutismAddon;
import autismclient.api.AutismAddons;

import com.example.addon.modules.ReachModule;

public final class ExampleAddon extends AutismAddon {
    public static final String ID = "autism-advanced-addon-template";

    @Override
    public int apiVersion() {
        return ApiVersion.CURRENT;
    }

    @Override
    public void onInitialize() {
        AutismAddons.modules().register(new ReachModule());
    }

    @Override
    public String getPackage() {
        return "com.example.addon";
    }
}

package com.example.addon.modules;

import com.example.addon.ExampleAddon;
import autismclient.api.module.IntSetting;
import autismclient.modules.Module;
import autismclient.modules.ModuleCategory;

public final class ReachModule extends Module {
    private static volatile boolean active;
    private static ReachModule instance;

    private final IntSetting range = add(new IntSetting("range", "Range", 60, 10, 100, 5)
        .group("General"));

    public ReachModule() {
        super(ExampleAddon.ID + ":reach", "Reach", ModuleCategory.MISC,
            "Extends block and entity interaction range.\nModule \"Reach\" by ReAgents and Claude!");
        instance = this;
    }

    @Override
    public void onEnable() {
        active = true;
    }

    @Override
    public void onDisable() {
        active = false;
    }

    public static boolean isActive() {
        return active;
    }

    public static double getReach() {
        return instance == null ? 0.0 : instance.range.get() / 10.0;
    }
}

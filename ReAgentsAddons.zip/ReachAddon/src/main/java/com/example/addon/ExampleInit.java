package com.example.addon;

import net.fabricmc.api.ClientModInitializer;

public final class ExampleInit implements ClientModInitializer {
    @Override
    public void onInitializeClient() {}
}

package com.example.addon.mixin;

import com.example.addon.modules.ReachModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class ReachMixin {
    @Inject(method = "blockInteractionRange", at = @At("HEAD"), cancellable = true)
    private void reach$block(CallbackInfoReturnable<Double> cir) {
        if (reach$applies()) cir.setReturnValue(ReachModule.getReach());
    }

    @Inject(method = "entityInteractionRange", at = @At("HEAD"), cancellable = true)
    private void reach$entity(CallbackInfoReturnable<Double> cir) {
        if (reach$applies()) cir.setReturnValue(ReachModule.getReach());
    }

    private boolean reach$applies() {
        return ReachModule.isActive() && (Object) this == Minecraft.getInstance().player;
    }
}
